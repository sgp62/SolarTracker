#ifndef _NMEA_CONFIG_H
#define _NMEA_CONFIG_H

#define	_NMEA_USE_FREERTOS								1

#endif
